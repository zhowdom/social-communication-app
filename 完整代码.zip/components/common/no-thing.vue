<template>
	<view
	class="flex flex-column align-center justify-center pt-5">
		<image src="/static/common/nothing.png"
		style="width: 300rpx;height: 300rpx;"></image>
		<text class="font-md">什么都没有</text>
	</view>
</template>

<script>
</script>

<style>
</style>
